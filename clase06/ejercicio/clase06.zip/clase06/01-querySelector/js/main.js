// document.querySelector('Selector de CSS');

const primerParrafo = document.querySelector('p');
console.log(primerParrafo);

console.log('>>>innerText del primer párrafo: (ANTES)');
console.log(primerParrafo.innerText);

primerParrafo.innerText = 'Nuevo contenido';
console.log('>>>innerText del primer párrafo: (DESPUÉS)');
console.log(primerParrafo.innerText);

const primerLi = document.querySelector('li');

console.log(primerLi.title);
primerLi.title = 'Ahora el título es este';
primerLi.innerText = 'Se cambió el título de este li';
console.log(primerLi.title);

const primerDestacado = document.querySelector('.destacado');
console.log(primerDestacado);

// primerDestacado.innerText = 'Hola, qué tal? <em>Este es el 1er párrafo</em> destacado';
primerDestacado.innerHTML = 'Hola, qué tal? <em>Este es el 1er párrafo</em> destacado';

const encabezadoPrincipal = document.querySelector('#encabezado-principal');
console.log(encabezadoPrincipal);
encabezadoPrincipal.textContent = 'Este es el encabezado principal';

const primerStrong = document.querySelector('strong');
console.log(primerStrong);

const primerStrongDestacado = document.querySelector('strong.destacado');
console.log(primerStrongDestacado);
