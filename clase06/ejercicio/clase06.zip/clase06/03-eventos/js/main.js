function saludar() {
    alert('Hola!!');
}

const btnSaludar1 = document.querySelector('#btn-saludar-1');
// console.log(btnSaludar1);
// btnSaludar1.innerText = 'Nuevo texto del botón';
btnSaludar1.onclick = saludar;

const btnSaludar2 = document.querySelector('#btn-saludar-2');
// btnSaludar2.onclick = saludar;
btnSaludar2.ondblclick = saludar;

const p1 = document.querySelector('#parrafo-1');
p1.innerText = 'Haceme click y saludo';
p1.title = 'Clickeame!';
p1.onclick = saludar;

// function imprimirLineasEnLaConsola () {
//     console.log('----------');
//     console.log('----------');
//     console.log('----------');
// }

const p2 = document.querySelector('#parrafo-2');
p2.innerText = 'Haceme click y escribo en la consola';
// p2.onclick = imprimirLineasEnLaConsola;
p2.onclick = function () {
    console.log('----------');
    console.log('----------');
    console.log('----------');
};

function modificarH1() {
    // const h1 = document.querySelector('h1');
    h1.innerText += '!';
}

const p3 = document.querySelector('#parrafo-3');
p3.innerText = 'Haceme click y modifico en h1';
p3.onclick = modificarH1;

const h1 = document.querySelector('h1');
h1.innerText = 'Clickeame para agregarme un "!"';
h1.onclick = modificarH1;

