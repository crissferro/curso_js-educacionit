const sectionFAQ = document.querySelector('#preguntas-frecuentes');

const btnMostrarFAQ = document.querySelector('#btn-mostrar-faq');
btnMostrarFAQ.onclick = function () {
    console.log('🐵 Se muestran las preguntas frecuentes');
    sectionFAQ.classList.remove('oculto');
};

const btnOcultarFAQ = document.querySelector('#btn-ocultar-faq');
btnOcultarFAQ.onclick = function () {
    console.log('🙈 Se ocultan las preguntas frecuentes');
    sectionFAQ.classList.add('oculto');
};
