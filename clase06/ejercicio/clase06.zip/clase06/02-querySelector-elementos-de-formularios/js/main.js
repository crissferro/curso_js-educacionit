const inputNombre = document.querySelector('#nombre');
console.log(inputNombre);
console.log(inputNombre.value);

const inputApellido = document.querySelector('#apellido');
console.log(inputApellido);
inputApellido.value = 'Value cargado con JS';
