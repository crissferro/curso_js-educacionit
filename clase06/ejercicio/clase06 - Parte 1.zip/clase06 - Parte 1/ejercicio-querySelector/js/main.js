/*
1 - Obtener con JS el primer elemento <p> y mostrarlo en la consola.
2 - Modificar el texto interno de dicho <p> por el texto "Se modificó este párrafo con JS".
3 - Mostrar en la consola el nuevo texto interno del <p> modificado.
4 - Obtener con JS el primer elemento <ul> y mostrarlo en la consola.
5 - Obtener con JS el primer elemento con clase "lista-2" y mostrarlo en la consola.
6 - Agregar al elemento con clase "lista-2" un título. Verificar en la página, pasando el cursor por arriba, si la modificación función correctamente.
7 - Leer con JS el texto interno del primer elemento <h3> y mostrarlo en la consola.
8 - Pisar el texto interno del primer <h1> con el mismo texto del primer <h3>.
*/