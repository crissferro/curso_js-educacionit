/*
const dia1 = 'lunes';
const dia2 = 'martes';
const dia3 = 'miércoles';
const dia4 = 'jueves';
const dia5 = 'viernes';
const dia6 = 'sábado';
const dia7 = 'domingo';
*/

// Índices:       0         1          2          3          4         5          6
const dias = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'];
console.log(dias);
console.log(dias.length);

/*
console.warn('Recorrido "manual" de un array:');

console.log('Día: ' + dias[0]);
console.log('---');

console.log('Día: ' + dias[1]);
console.log('---');

console.log('Día: ' + dias[2]);
console.log('---');

console.log('Día: ' + dias[3]);
console.log('---');

console.log('Día: ' + dias[4]);
console.log('---');

console.log('Día: ' + dias[5]);
console.log('---');

console.log('Día: ' + dias[6]);
console.log('---');

*/

// console.log('Día: ' + dias[7]); // undefined
// console.log('---');

// console.log('Día: ' + dias[908]); // undefined
// console.log('---');

console.warn('Recorrido automatizado de un array:');

for (let i = 0; i < dias.length; i++) {
    console.log('Día: ' + dias[i]);
    console.log('---');
}


console.warn('-----------------');

//                        0    1     2      3     4      5
const costoArticulos = [8500, 4700, 6000, 2800, 11400, 1500, ];
console.table(costoArticulos);

costoArticulos[0] = 400000;
costoArticulos[3] = 50;
costoArticulos[6] = 25;     // Índice 6
costoArticulos[7] = 15000;  // Índice 7
costoArticulos[8] = 800;    // Índice 8
costoArticulos[9] = 4000;   // Índice 9
costoArticulos.push(2000);  // Índice 10
costoArticulos.push(3000);  // Índice 11
costoArticulos.push(7000);  // Índice 12
console.table(costoArticulos);

let acumulador = 0;
for (let i = 0; i < costoArticulos.length; i++) {
    console.log(`Costo del artículo ${i}: ${costoArticulos[i]}`);
    acumulador += costoArticulos[i];
}
console.log(`El total es ${acumulador}`);


costoArticulos.pop();                       // Extrae el último índice (era el 12)
console.table(costoArticulos);
costoArticulos.pop();                       // Extrae el último índice (era el 11)
const exContenido10 = costoArticulos.pop(); // Extrae el último índice (era el 10)
console.log(`Elemento eliminado: ${exContenido10}`);
costoArticulos.pop();                       // Extrae el último índice (era el 9)
console.table(costoArticulos);

