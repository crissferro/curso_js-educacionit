saludar();  // También funciona

function saludar() {
    console.warn('Hola!');
    console.warn('Cómo estás?');
    imprimirSeparador();
}

function imprimirSeparador() {
    console.error('_________________________');
}

console.log('Algo de código...');
console.log('Algo de código...');
console.log('Algo de código...');
saludar();
saludar();
console.log('Algo de código...');
saludar();
console.log('Algo de código...');
console.log('Algo de código...');
console.log('Algo de código...');
console.log('Algo de código...');
imprimirSeparador();
console.log('Algo de código...');
console.log('Algo de código...');
console.log('Algo de código...');

