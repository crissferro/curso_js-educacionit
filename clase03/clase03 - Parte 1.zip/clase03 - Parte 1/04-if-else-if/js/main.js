/*
    <----

    if (condición 1) {
        ... código a ejecutar si la condición 1 se cumple
    } else if (condición 2) {
        ... código a ejecutar si la condición 1 NO se cumple y se cumple la condición 2
    } else if (condición 3) {
        ... código a ejecutar si las condiciones anteriores NO se cumplen y se cumple la condición 3
    } else if (condición 4) {
        ... código a ejecutar si las condiciones anteriores NO se cumplen y se cumple la condición 4
    } else if (condición 5) {
        ... código a ejecutar si las condiciones anteriores NO se cumplen y se cumple la condición 5
    } else {
        ... código a ejecutar si las condiciones anteriores NO se cumplen
    }

    <----
*/

// const curso = 'PHP';
// const curso = 'SQL';
// const curso = 'jQuery';
const curso = 'HTML';
// const curso = 'C#';

// const costo = 4000;
const costo = 0;

if (curso === 'PHP') {
    console.log('El curso de PHP se dicta los martes y jueves de 15 a 18h.\nEl costo es de $' + costo);
} else if (curso === 'SQL') {
    console.log('El curso de SQL se dicta los miércoles y viernes de 19 a 22h.\nSu valor es de $' + costo);
} else if (curso === 'jQuery') {
    console.log('El curso de jQuery no está activo de momento');
} else if (curso === 'HTML') {
    console.log('El curso de HTML se dicta los lunes, miércoles y viernes de 10 a 12h');
    if (costo === 0) {
        console.log('Tenemos una buena noticia para vos:');
        console.log('El curso es gratuito!');
        console.log('🥳🎉');
    } else {
        console.log('El curso tiene un costo de ' + costo);
    }
} else {
    console.error('Curso incorrecto');
}
