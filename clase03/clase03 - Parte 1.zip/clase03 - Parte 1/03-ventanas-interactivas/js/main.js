const continuar = confirm('Querés ingresar tus datos?');
console.log('continuar:', typeof continuar, continuar);

if (continuar) {

    const nombre = prompt('Ingresá tu nombre:');
    console.log('nombre:', typeof nombre, nombre);
    
    if (nombre === '') {
        console.log('Dejaste un texto vacío y presionaste aceptar.');
    }

    if (nombre === null) {
        console.log('Presionaste cancelar.');
    }
    
    const apellido = prompt('Ingresá tu apellido:', 'Smith');
    console.log('apellido:', typeof apellido, apellido);

    if (apellido) {
        console.log('Tu apellido es: ' + apellido);
    } else {
        console.log('No ingresaste tu apellido.');
    }
    
    if (!apellido) {
        console.log('No ingresaste tu apellido.');
    } else {
        console.log('Tu apellido es: ' + apellido);
    }
    
    alert(nombre);
    alert(apellido);
    
} else {
    console.warn('Se decidió continuar sin completar los datos...');
}