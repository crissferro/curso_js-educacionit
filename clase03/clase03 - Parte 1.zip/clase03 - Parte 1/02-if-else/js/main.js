/*
    if (condición) {
        ... código a ejecutar si la condición se cumple ...
    } else {
        ... código a ejecutar si la condición NO se cumple ...
    }

    Operadores comparativos
        <       menor
        <=      menor o igual
        >       mayor
        >=      mayor o igual
        ==      igual (compara el valor, ignorando el tipo de dato)
        ===     estrictamente igual igual (compara el valor y tipo de dato)
        !=      distinto
        !==     estrictamente distinto
*/

console.warn('Ejemplo 1');
if (true) {
    console.log('Se cumple');
} else {
    console.log('No se cumple');
}

console.warn('Ejemplo 2');
if (false) {
    console.log('Se cumple');
} else {
    console.log('No se cumple');
}

console.warn('Ejemplo 3');
let saldo = 36500;
if (saldo >= 4000) {
    console.log('El saldo alcanza para realizar la compra.');
} else {
    console.log('Saldo insuficiente');
}

console.warn('Ejemplo 4');
saldo = 240;
if (saldo >= 4000) {
    console.log('El saldo alcanza para realizar la compra.');
} else {
    console.log('Saldo insuficiente');
}

console.warn('Ejemplo 5');
const dia = 'domingo';
// const dia = 'martes';
if (dia === 'domingo') {
    console.log('Hoy el local se encuentra cerrado. Por favor, acercate de lunes a sábados');
} else {
    console.log('Hoy atenemos de 10 a 18h');
}

console.warn('Ejemplo 6');
if (300) {          // true
    console.log('Se cumple');
} else {
    console.log('No se cumple');
}

console.warn('Ejemplo 7');
if (0) {            // false
    console.log('Se cumple');
} else {
    console.log('No se cumple');
}

console.warn('Ejemplo 8');
if ('abc') {        // true
    console.log('Se cumple');
} else {
    console.log('No se cumple');
}

console.warn('Ejemplo 9');
if ('') {           // false
    console.log('Se cumple');
} else {
    console.log('No se cumple');
}

console.warn('Ejemplo 10');
if (null) {         // false
    console.log('Se cumple');
} else {
    console.log('No se cumple');
}

console.warn('Ejemplo 11');
if (undefined) {    // false
    console.log('Se cumple');
} else {
    console.log('No se cumple');
}

