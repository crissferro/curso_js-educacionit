/*
    if (condición) {
        ... código a ejecutar si la condición se cumple ...
    }
*/

console.warn('Ejemplo 1');
if (true) {
    console.log('Se cumple');
}

console.warn('Ejemplo 2');
if (false) {
    console.log('Se cumple');
}

console.warn('Ejemplo 3');
let saldo = 36500;
if (saldo >= 4000) {
    console.log('El saldo alcanza para realizar la compra.');
}

console.warn('Ejemplo 4');
saldo = 240;
if (saldo >= 4000) {
    console.log('El saldo alcanza para realizar la compra.');
}

